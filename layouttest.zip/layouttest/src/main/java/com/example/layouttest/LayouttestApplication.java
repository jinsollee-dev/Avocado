package com.example.layouttest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LayouttestApplication {

  public static void main(String[] args) {
    SpringApplication.run(LayouttestApplication.class, args);
  }

}
